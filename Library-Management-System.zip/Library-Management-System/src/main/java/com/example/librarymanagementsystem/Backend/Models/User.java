package com.example.librarymanagementsystem.Backend.Models;

public interface User {
    String getFirstName();
    String getLastName();
    String getEmail();
    String getPassword();
    int getId();
}
